import Navbar from '../../Web/Navbar';
import LandingPageContent from './LandingPageContent';

const About = () => {
    return(
        <>
            <Navbar />
            <LandingPageContent />
        </>
    )
}

export default About;