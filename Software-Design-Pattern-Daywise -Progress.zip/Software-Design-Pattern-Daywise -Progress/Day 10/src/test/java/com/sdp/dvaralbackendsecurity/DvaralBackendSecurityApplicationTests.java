package com.sdp.dvaralbackendsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvaralBackendSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
