package com.sdp.dvaralbackendsecurity.model;

public enum TokenType {

    BEARER
}
