package com.sdp.dvaralbackendsecurity.enums;

public enum Role {
    USER,
    ADMIN,
    MANAGER
}
